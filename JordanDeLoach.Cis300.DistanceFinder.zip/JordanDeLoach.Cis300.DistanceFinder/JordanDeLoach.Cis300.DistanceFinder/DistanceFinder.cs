﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace JordanDeLoach.Cis300.DistanceFinder
{
    public partial class uxDistancefinder : Form
    {
        public uxDistancefinder()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles a button click that opens the file dialog and attempts top open the image on the panel, handling exceptions as needed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxOpenFileButton_Click(object sender, EventArgs e)
        {
            if (uxOpenFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Bitmap image = new Bitmap(uxOpenFileDialog.FileName);
                    uxPictureBox.Image = image;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "\n" + ex.StackTrace, "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                }
            }
        }
        /// <summary>
        /// Handles a click to the button of the color selector.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxOpenColorButton_Click(object sender, EventArgs e)
        {
            if (uxColorDialog.ShowDialog() == DialogResult.OK)
            {
                uxOpenColorButton.BackColor = uxColorDialog.Color;
            }
        }
    }
}
